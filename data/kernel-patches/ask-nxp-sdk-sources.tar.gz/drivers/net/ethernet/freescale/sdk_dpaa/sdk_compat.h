/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Compatibility shims for NXP SDK drivers on mainline 6.6 kernel.
 * NXP's lf-6.6.y adds phylink/phy symbols not present in mainline.
 */
#ifndef __SDK_COMPAT_H
#define __SDK_COMPAT_H

#include <linux/phy.h>
#include <linux/ethtool.h>

/* NXP added PHY_INTERFACE_MODE_2500SGMII; mainline 6.6 has 2500BASEX */
#ifndef PHY_INTERFACE_MODE_2500SGMII
#define PHY_INTERFACE_MODE_2500SGMII PHY_INTERFACE_MODE_2500BASEX
#endif

/* NXP added phylink_interface_max_speed() to phylink.h; not in mainline 6.6 */
static inline int phylink_interface_max_speed(phy_interface_t interface)
{
	switch (interface) {
	case PHY_INTERFACE_MODE_100BASEX:
	case PHY_INTERFACE_MODE_REVRMII:
	case PHY_INTERFACE_MODE_RMII:
	case PHY_INTERFACE_MODE_SMII:
	case PHY_INTERFACE_MODE_REVMII:
	case PHY_INTERFACE_MODE_MII:
		return SPEED_100;

	case PHY_INTERFACE_MODE_TBI:
	case PHY_INTERFACE_MODE_MOCA:
	case PHY_INTERFACE_MODE_RTBI:
	case PHY_INTERFACE_MODE_1000BASEX:
	case PHY_INTERFACE_MODE_1000BASEKX:
	case PHY_INTERFACE_MODE_TRGMII:
	case PHY_INTERFACE_MODE_RGMII_TXID:
	case PHY_INTERFACE_MODE_RGMII_RXID:
	case PHY_INTERFACE_MODE_RGMII_ID:
	case PHY_INTERFACE_MODE_RGMII:
	case PHY_INTERFACE_MODE_PSGMII:
	case PHY_INTERFACE_MODE_QSGMII:
	case PHY_INTERFACE_MODE_QUSGMII:
	case PHY_INTERFACE_MODE_SGMII:
	case PHY_INTERFACE_MODE_GMII:
		return SPEED_1000;

	case PHY_INTERFACE_MODE_2500BASEX:
		return SPEED_2500;

	case PHY_INTERFACE_MODE_5GBASER:
		return SPEED_5000;

	case PHY_INTERFACE_MODE_XGMII:
	case PHY_INTERFACE_MODE_RXAUI:
	case PHY_INTERFACE_MODE_XAUI:
	case PHY_INTERFACE_MODE_10GBASER:
	case PHY_INTERFACE_MODE_10GKR:
	case PHY_INTERFACE_MODE_USXGMII:
		return SPEED_10000;

	case PHY_INTERFACE_MODE_25GBASER:
		return SPEED_25000;

	case PHY_INTERFACE_MODE_XLGMII:
		return SPEED_40000;

	case PHY_INTERFACE_MODE_INTERNAL:
	case PHY_INTERFACE_MODE_NA:
	case PHY_INTERFACE_MODE_MAX:
	default:
		return SPEED_UNKNOWN;
	}
}

#endif /* __SDK_COMPAT_H */

/* skb_recycle() was removed from mainline kernel ~3.17.
 * NXP SDK dpaa_eth_sg.c uses it to reset an SKB for buffer reuse.
 * This compat version resets SKB metadata while preserving the data buffer.
 */
#include <linux/skbuff.h>

static inline void skb_recycle(struct sk_buff *skb)
{
	struct skb_shared_info *shinfo;

	skb_release_head_state(skb);

	shinfo = skb_shinfo(skb);
	memset(shinfo, 0, offsetof(struct skb_shared_info, dataref));
	atomic_set(&shinfo->dataref, 1);

	memset(skb, 0, offsetof(struct sk_buff, tail));
	skb->data = skb->head + NET_SKB_PAD;
	skb_reset_tail_pointer(skb);
}
